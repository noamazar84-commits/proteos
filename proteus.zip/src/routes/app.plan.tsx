import { Link, createFileRoute } from '@tanstack/react-router'
import { ArrowRight, Dumbbell, Utensils } from 'lucide-react'
import { NeedsPathway } from '@/components/PageHeader'
import { getPathway } from '@/lib/fixtures'
import { useAppState } from '@/lib/store'

export const Route = createFileRoute('/app/plan')({ component: PlanScreen })

function PlanScreen() {
  const state = useAppState()
  const plan = state.months[state.months.length - 1]
  if (!state.profile || !plan) return <NeedsPathway />

  const pathway = getPathway(state.profile.pathwayId)
  const trackLabel = pathway.id === 'glp1' ? 'GLP-1' : pathway.id === 'bariatric' ? 'Sleeve' : 'General Weight Loss'

  return <div className="clean-plan-hub mx-auto flex h-[calc(100dvh-2rem)] max-w-7xl flex-col justify-center gap-8 overflow-hidden py-5 sm:gap-10 sm:py-8">
    <header className="text-center"><h1 className="glow-title font-display text-4xl font-extrabold tracking-tight text-white sm:text-6xl">Your Solid Plan is Ready</h1><p className="mx-auto mt-3 max-w-2xl text-sm text-white sm:text-base">Open a roadmap below. Track your data, use Meal Scanner, chat with your AI Coach, and review progress from the left sidebar.</p></header>

    <section className="clean-plan-grid clean-plan-grid-two grid grid-cols-2 gap-3 sm:gap-5" aria-label="Your plan options">
      <HubCard icon={<Utensils className="h-8 w-8" />} eyebrow={`${trackLabel} pathway`} title={`${trackLabel} Nutrition`} body={pathway.id === 'glp1' ? 'Protein anchors, smaller portions, hydration pacing, and appetite-aware meal options.' : pathway.id === 'bariatric' ? 'Micro-meals, protein-first portions, separated liquids and solids, and texture-aware progression.' : 'Structured caloric deficit, balanced macros, and practical daily meal choices.'} href="/app/protein" action="Open Roadmap" />
      <HubCard icon={<Dumbbell className="h-8 w-8" />} eyebrow={`${trackLabel} pathway`} title={`${trackLabel} Fitness`} body={pathway.id === 'glp1' ? 'Gentle movement rhythm with strength work to protect lean mass and recovery.' : pathway.id === 'bariatric' ? 'Progressive low-impact recovery with conservative volume and post-surgical awareness.' : 'Multi-phase strength, conditioning, and daily movement progression.'} href="/app/fitness" action="Open Roadmap" />
    </section>

  </div>
}

function HubCard({ icon, eyebrow, title, body, href, action }: { icon: React.ReactNode; eyebrow: string; title: string; body: string; href: '/app/protein' | '/app/fitness' | '/app/check-in'; action: string }) {
  return <article className="clean-plan-card group flex min-w-0 flex-col rounded-2xl border border-volt-2/75 bg-gradient-to-b from-volt/[0.18] via-[#10234b] to-[#080d1b] p-4 text-center shadow-[0_0_28px_rgba(61,139,255,0.28),inset_0_0_28px_rgba(111,182,255,0.08)] transition duration-200 hover:-translate-y-1 hover:border-[#b8e6ff] hover:bg-volt/[0.24] hover:shadow-[0_0_42px_rgba(61,180,255,0.55),inset_0_0_34px_rgba(111,182,255,0.14)] sm:p-7"><span className="mx-auto grid h-14 w-14 shrink-0 place-items-center rounded-2xl border border-volt/50 bg-volt/10 text-volt-2 shadow-[0_0_18px_rgba(61,139,255,0.3)] sm:h-16 sm:w-16">{icon}</span><p className="mt-5 text-[10px] font-bold uppercase tracking-[0.16em] text-volt-2 sm:text-xs">{eyebrow}</p><h2 className="mt-2 font-display text-xl font-extrabold leading-tight text-white sm:text-3xl">{title}</h2><p className="mt-3 min-h-20 text-xs leading-relaxed text-white sm:text-sm">{body}</p><Link to={href} className="btn-glow btn-sm mt-auto inline-flex w-full items-center justify-center gap-2 px-2 py-3 text-xs sm:text-sm">{action} <ArrowRight className="h-4 w-4" /></Link></article>
}
